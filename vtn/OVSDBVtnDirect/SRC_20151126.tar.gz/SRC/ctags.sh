ctags *.cpp
ctags -a *.hpp
ctags -a *.h
